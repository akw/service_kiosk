require 'json'
require 'rest_client'
require 'open-uri'

module ServiceKiosk
  class RemoteService
    def initialize(kiosk, service)
      @endpoint = external_host(kiosk + '/' + service)
    end

    def url(id=nil, input=nil)
      @endpoint + (id ? ('/' + id) : '') + (input ? '?data=' + CGI::escape(input.to_json) : '')
    end

    def action_url(action)
      @endpoint + '/' + action
    end

    def external_host(id)
      # TODO: this hack is to correct the fact that sinatra using jruby on vbox ubuntu won't
      #   bind properly to all interfaces 0.0.0.0
      host = /inet addr:(\S+)/m.match(`ifconfig eth0`)[1]
      id.sub('localhost', host)
    end

    def call(action, input={})
      response = RestClient.post action_url(action), {data: input.to_json}
      JSON.parse response
    end

    def list(input={})
      response = RestClient.post action_url('list'), {data: input.to_json}
      JSON.parse response
    end

    def read(input={})
      response = RestClient.post action_url('read'), {data: input.to_json}
      JSON.parse response
    end

    def create(input={})
      response = RestClient.post action_url('create'), {data: input.to_json}
      JSON.parse response
    end

    def update(input={})
      response = RestClient.post action_url('update'), {data: input.to_json}
      JSON.parse response
    end

    def delete(input={})
      response = RestClient.post action_url('delete'), {data: input.to_json}
      JSON.parse response
    end
  end
end
