#!/usr/bin/env bash

foreman start -f ../../lib/Procfile.kiosk -d `pwd`
