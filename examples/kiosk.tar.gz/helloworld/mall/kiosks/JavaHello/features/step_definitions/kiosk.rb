require '../../lib/kiosk.rb'
